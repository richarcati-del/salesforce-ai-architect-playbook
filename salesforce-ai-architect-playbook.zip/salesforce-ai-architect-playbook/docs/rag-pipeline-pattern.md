# RAG Pipeline Pattern

## Objective
Ground AI-generated responses in trusted enterprise data so agents provide accurate, safe, and context-aware answers.

## Retrieval Sources

- Salesforce CRM records
- Salesforce Knowledge articles
- Data Cloud unified profiles
- Product catalogs
- Support policies
- Marketing engagement history
- External systems through REST/SOAP APIs
- AWS-hosted datasets or data lake sources

## Pipeline Flow

1. Ingest approved enterprise content.
2. Normalize records and metadata.
3. Index content for semantic and keyword retrieval.
4. Retrieve relevant context based on user intent.
5. Pass retrieved context into the AI agent prompt.
6. Generate response with citations or source references.
7. Apply safety and compliance checks.
8. Log result and user feedback for continuous improvement.

## Production Considerations

- Data freshness
- Permission-aware retrieval
- PII handling
- Auditability
- Latency monitoring
- Fallback behavior
- Human review paths
