# Interview Talking Points

## Question: Have you built agentic workflows, RAG pipelines, or production-grade AI tooling?

Yes. In my current Salesforce architecture work, I have designed AI-enabled workflows that combine CRM data, behavioral signals, automation logic, and API-driven orchestration. The foundation is very similar to agentic and RAG-based architecture: unify the data, retrieve the right context, apply business rules, trigger the appropriate workflow, and escalate when needed.

At Nikon, I used Einstein AI, Marketing Cloud, behavioral data, and personalization frameworks to drive intelligent campaign decisioning. I also built API-driven integration patterns that connected Salesforce with external systems, creating the kind of trusted data layer required for AI agents to operate safely.

More recently, I have been positioning this architecture toward Agentforce, Data Cloud, and RAG-style workflows where Salesforce acts as the intelligent core. My strength is designing the enterprise-grade data, integration, governance, and workflow layer that makes AI tools production-ready.

## Question: Do you have open-source contributions?

Most of my enterprise work has been within client-owned systems, so I have not historically published client implementation code publicly. However, I created this public architecture playbook to share reusable patterns around Salesforce AI architecture, Agentforce-style workflows, RAG pipeline design, API orchestration, and governance.
